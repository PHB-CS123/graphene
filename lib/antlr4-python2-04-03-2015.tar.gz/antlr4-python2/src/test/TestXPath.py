__author__ = 'ericvergnaud'

import unittest
import time
import uuid

class TestXPath(unittest.TestCase):

    def testLoadable(self):
        from antlr4.xpath import XPath
        self.assertTrue(True)




if __name__ == '__main__':
    unittest.main()
