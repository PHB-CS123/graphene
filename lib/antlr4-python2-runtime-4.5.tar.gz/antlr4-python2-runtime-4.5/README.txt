This is the Python 2.7 runtime for AntLR.
Visit the AntLR web sites for more information:
http://www.antlr.org
http://theantlrguy.atlassian.net/wiki/display/ANTLR4/Python+Target